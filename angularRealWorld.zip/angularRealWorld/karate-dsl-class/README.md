# karate-dsl-class
Source code from my Karate DSL class

Link to the class on Udemy: https://www.udemy.com/course/karate-dsl-api-automation-and-performance-from-zero-to-hero/?referralCode=9D858B912F18235A4CF8
