import React from 'react'

const Maybe = ({ test, children }) => <>{test && children}</>

export default Maybe
