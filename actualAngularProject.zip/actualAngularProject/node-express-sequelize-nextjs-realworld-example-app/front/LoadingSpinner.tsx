import React from 'react'

const LoadingSpinner = () => <div className="loading-spinner" />

export default LoadingSpinner
