import IndexPage from 'front/IndexPage'
export default IndexPage
import { getStaticPropsHoc } from 'back/IndexPage'
export const getStaticProps = getStaticPropsHoc
