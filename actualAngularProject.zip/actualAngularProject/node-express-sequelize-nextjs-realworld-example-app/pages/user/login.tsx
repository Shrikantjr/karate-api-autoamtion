import LoginPageHoc from 'front/LoginPage'
export default LoginPageHoc({})
