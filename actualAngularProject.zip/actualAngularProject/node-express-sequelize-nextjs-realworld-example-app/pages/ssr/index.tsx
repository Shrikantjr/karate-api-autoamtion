import IndexPage from 'front/IndexPage'
export default IndexPage
import { getServerSidePropsHoc } from 'back/IndexPage'
export const getServerSideProps = getServerSidePropsHoc
