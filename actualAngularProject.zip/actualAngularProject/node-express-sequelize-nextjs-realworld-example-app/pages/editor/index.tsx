import ArticleEditorHoc from 'front/ArticleEditor'

export default ArticleEditorHoc(true)
